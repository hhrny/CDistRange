//This file is part of SECONDO.

//Copyright (C) 2004, University in Hagen, Department of Computer Science, 
//Database Systems for New Applications.

//SECONDO is free software; you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation; either version 2 of the License, or
//(at your option) any later version.

//SECONDO is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.

//You should have received a copy of the GNU General Public License
//along with SECONDO; if not, write to the Free Software
//Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package wrapper;	

import java.lang.reflect.*;

/** A class containing a class and a method.
  * This is required to handle the wrapping of inherited methods.
  **/

public class ClassMethod{

   /** Creates a new instance of ClassMethod */
   public ClassMethod(Class c,Method M){
       this.c = c;
       this.m = M;
   }

   /** Returns a String representatio of this. */
   public String toString(){
     return "[C:"+c+" , M:"+m+"]";
   }

   /** The managed Class */ 
   public Class c;
   /** The managed Method */
   public Method m;
   /** a additional number */
   public int number=0;
}
