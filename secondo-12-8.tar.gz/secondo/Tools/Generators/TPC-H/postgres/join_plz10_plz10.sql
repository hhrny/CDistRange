EXPLAIN select count(*) from PLZ10 as A, PLZ10 as B  where A.P10_PLZ=B.P10_PLZ;
select count(*) from PLZ10 as A, PLZ10 as B  where A.P10_PLZ=B.P10_PLZ;
\q
