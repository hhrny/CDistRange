SELECT count(*) FROM lineitem;
\q

