select count(*) from PLZ, PLZ10 where P_PLZ=P10_PLZ;
\q
