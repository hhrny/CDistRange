July 2008, M. Spiekermann

This code was downloaded from 

  ftp://ftp.research.microsoft.com/users/viveknar/tpcdskew

and revised to compile it with gcc 4.1.2. Currently, the query generation
tool still does not work.


The command script tpcgen.sh can be used to do a convenient import of the
generated data into an SECONDO database. Type 

  tpcgen.sh -h

for online help.

