
package tools.downloadmanager;

public enum DownloadState {CANCEL,DONE,BROKEN};
