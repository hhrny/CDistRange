
package tools;

import java.io.File;

public interface Cacheable{
  public int getUsedMem();

}
