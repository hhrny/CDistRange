/* Automatically generated file, do not edit by hand. */
wCostFactor(1000000).
vCostFactorCPU(1).
