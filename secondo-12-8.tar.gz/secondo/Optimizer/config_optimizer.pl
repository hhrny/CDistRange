/* Automatically generated file, do not edit by hand. */
:- setOption(standard).
:- setOption(debug).
:- setOption(autoSamples).
:- setOption(autosave).
:- debugLevel(selectivity).
